
int yyparse(void);

int main()
{
    return yyparse();
}
