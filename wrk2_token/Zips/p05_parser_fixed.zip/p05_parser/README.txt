
# Paso 05: Parser base con Bison + Flex

## Instrucciones

1. Compilar el parser:
    make

2. Ejecutar el parser sobre un programa Fortran válido:
    ./parser < programa.f

El parser validará si el programa cumple con la gramática base.
